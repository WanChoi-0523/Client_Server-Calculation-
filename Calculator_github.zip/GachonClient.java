/*
 * Writer : Choi SeungWan
 * Purpose : Write a client code that send request to server to get answer
 */

import java.io.*;
import java.net.*;
import java.util.*;

public class GachonClient {
    public static void main(String[] args) {
        BufferedReader in = null;
        BufferedWriter out = null;
        Socket socket = null;
        Scanner scanner = new Scanner(System.in);
        String local = "";
        int myport = 0;


        //Read file to access server
        String filePath = "server_info.txt"; // 파일 경로를 수정하세요.

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            local = br.readLine();

            String secondLine = br.readLine();
            myport = Integer.parseInt(secondLine);

        } catch (IOException e) {
            e.printStackTrace();
        }


        try {
            socket = new Socket("localhost", myport);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            while (true) {
                System.out.print("Enter Fromula(Ex : ADD 1 2) : "); 
                String outputMessage = scanner.nextLine(); 
                if (outputMessage.equalsIgnoreCase("bye")) {
                    out.write(outputMessage + "\n"); 
                    out.flush();
                    break; //  If read bye, break!
                }
                out.write(outputMessage + "\n"); // Send reqeust to server
                out.flush();
                String inputMessage = in.readLine(); // get answer from server.
                StringTokenizer clientToken = new StringTokenizer(inputMessage, " ");
                String first = clientToken.nextToken();
                String sec = clientToken.nextToken();

                // Output results according to the first word of the result
                if(first.equals("RES0"))
                    System.out.println("Result : " + sec);
                else if(first.equals("ERROR1"))
                    System.out.println("Number Count Error!");
                else if(first.equals("ERROR2"))
                    System.out.println("Can't Divide to 0");
                else if(first.equals("ERROR3"))
                    System.out.println("Undefined OpCode");
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                scanner.close();
                if (socket != null)
                    socket.close(); // Close
            } catch (IOException e) {
                System.out.println("Unknown Error Detected!");
            }
        }
    }
}
