/*
 * Writer : Choi SeungWan
 * Purpose : Write a server code that get request and send response
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class GachonServer {
    public static int count = 0;    // count the number of clients

    public static void main(String[] args) {
        int myport = 9999;
        //InetAddress ip = InetAddress.getLocalHost();

        String filePath = "server_info.txt"; 
        
        //When you start server, edit the file.
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            
            bw.write("localhost");
            bw.newLine(); 

            bw.write(Integer.toString(myport));
            bw.newLine(); 

        } catch (IOException e) {
            e.printStackTrace();
        }

        ExecutorService threadPool = Executors.newCachedThreadPool();

        ServerSocket listener = null;
        //Open socket and waiting clients
        try {
            listener = new ServerSocket(myport);
            System.out.println("Waiting for connections...");

            while (true) {
                Socket socket = listener.accept();
                System.out.println("Client connected: " + socket);

                // Create a new thread (Runnable) for each client and submit it to the ThreadPool
                threadPool.submit(new ClientHandler(socket));
                count++; // Add the number of clients
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (listener != null)
                    listener.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Shutdown the ThreadPool when the server exits
            threadPool.shutdown();
        }
    }
}

//Handle multiple users
class ClientHandler implements Runnable {
    private Socket socket;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }
    public static String Calc(String exp) {
        StringTokenizer st = new StringTokenizer(exp, " ");
        if (st.countTokens() != 3)
            return "ERROR1 WrongCount"; //If too much components, send error
        String res = "";

        //Read Request
        String opcode = st.nextToken();
        int op1 = Integer.parseInt(st.nextToken());
        int op2 = Integer.parseInt(st.nextToken());

        if(opcode.equals("DIV") && op2 == 0) {
            res = "ERROR2 Div0";
            return res;
        }

        //Calculate and response
        switch (opcode) {
            case "ADD":
                res = "RES0 " + Integer.toString(op1 + op2);
                break;
            case "DEL":
                res = "RES0 " + Integer.toString(op1 - op2);
                break;
            case "MUL":
                res = "RES0 " + Integer.toString(op1 * op2);
                break;
            case "DIV" : 
                res = "RES0 " + Integer.toString(op1 / op2);
                break;
            default:
                res = "ERROR3 Undefined";
        }
        return res;
    }

    @Override
    public void run() {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        ) {
            while (true) {
                String inputMessage = in.readLine();
                
                //If clinet, send 'bye', close connection between that clients
                if (inputMessage == null || inputMessage.equalsIgnoreCase("bye")) {
                    System.out.println("Client disconnected: " + socket);
                    GachonServer.count--;
                    break; 
                }

                System.out.println("Received from client " + socket + ": " + inputMessage);

                String res = Calc(inputMessage);
                out.write(res + "\n");
                out.flush();
            }
        } catch (IOException e) {
            System.out.println("Error handling client: " + e.getMessage());
        } finally {
            try {
                if (socket != null) {
                    socket.close();
                }
                if(GachonServer.count == 0)
                    System.exit(0); // If clients number are 0, close program
                    
            } catch (IOException e) {
                System.out.println("Error closing client socket: " + e.getMessage());
            }
        }
    }
}